<?php
/**
 * 全局启动函数
 */
function wyf_start(){
	//记录访问日志
	//Log::error(Request::ip().'：'.$_SERVER['HTTP_USER_AGENT'].'-'.Request::url());
}
