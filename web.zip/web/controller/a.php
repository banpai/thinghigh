<?php
echo "hi all";
$aa = "ababa";