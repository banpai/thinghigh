<?php
return array(
	'blue' => '蓝色',
	'green' => '绿色',
	'brown' => '棕色',
	'purple' => '姿色',
	'red' => '红色',
	'greyblue' => '灰蓝色',
	'repost_err' => '重复提交错误',
	'select_please' =>'--请选择--',
);